function ex2(){
    let primeiro = document.getElementById("inserir").value;
    let segundo = document.getElementById("inserir2").value;
    soma = parseInt(primeiro) + parseInt(segundo);
    let resultado = document.getElementById('soma');
    resultado.innerHTML = soma
}