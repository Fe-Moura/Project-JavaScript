var canvas = document.getElementById("myCanvas");
var ctx = canvas.getContext("2d");

function desenharRetangulos(){
    ctx.beginPath();
    ctx.fillStyle = "blue"; // prenchimento
    ctx.fillRect(0, 0, 50,50);

    ctx.beginPath();
    ctx.fillStyle = "red";
    ctx.fillRect(250,0,50,50)

    ctx.beginPath();
    ctx.fillStyle= "yellow"
    ctx.fillRect(0, 235, 32,55)

    ctx.beginPath();
    ctx.fillStyle = "yellow";
    ctx.fillRect(0, 268, 65, 32)

    ctx.beginPath();
    ctx.fillStyle = "black";
    ctx.fillRect(270, 240, 37, 55)

    ctx.beginPath();
    ctx.fillStyle = "black";
    ctx.fillRect(236, 270, 64, 32)

    ctx.beginPath();
    ctx.fillStyle = "cyan"
    ctx.fillRect(0, 150, 30, 30)

    ctx.beginPath();
    ctx.fillStyle = "cyan"
    ctx.fillRect(0, 120, 30, 30)

    ctx.beginPath();
    ctx.fillStyle = "cyan"
    ctx.fillRect(270, 135, 30, 30)

    ctx.beginPath();
    ctx.fillStyle = "red"
    ctx.fillRect(110, 150, 40, 40)

}
function desenharLinhas(){
    ctx.beginPath(); //indica que vai começar um ponto
    ctx.moveTo(0,150); // coordenada de partida
    ctx.lineTo(300, 150);// coordenada de saída
    ctx.strokeStyle = "green"; //cor de uma linha
    ctx.stroke(); //chamando o stroke

    ctx.beginPath();
    ctx.moveTo(300, 0);
    ctx.lineTo(150, 150);
    ctx.strokeStyle = "red";
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0,0);
    ctx.lineTo(150,150);
    ctx.strokeStyle = "blue";
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(150,150);
    ctx.lineTo(150,300);
    ctx.strokeStyle = "black";
    ctx.stroke();
}
function desenharArcos(){
    ctx.beginPath();
    ctx.arc(150,120, 15, 0, 2*Math.PI); //definindo um círculo
    ctx.fillStyle = "cyan";
    ctx.fill();

    ctx.beginPath();
    ctx.arc(150,300, 40, 0, 2*Math.PI);
    ctx.fillStyle = "cyan";
    ctx.fill();

    ctx.beginPath();
    ctx.arc(150,150, 60, Math.PI, 2*Math.PI); //definindo um círculo
    ctx.strokeStyle = "green";


    ctx.beginPath();
    ctx.arc(150,150, 60, Math.PI, 2*Math.PI); //definindo um círculo
    ctx.strokeStyle = "green";
    ctx.stroke();

    ctx.beginPath();
    ctx.fillStyle = "yellow"
    ctx.arc(230, 220, 15, 0, 2*Math.PI);
    ctx.stroke();
    ctx.fill();

    ctx.beginPath() ;
    ctx.fillStyle = "yellow";
    ctx.arc(80, 220, 15, 0, 2*Math.PI);
    ctx.fill();

    ctx.beginPath();
    ctx.strokeStyle = "green";
    ctx.arc(150, 150, 80, 30.64, 2*Math.PI);
    ctx.stroke();

    ctx.beginPath();
    ctx.strokeStyle = "green";
    ctx.arc(150, 150, 80, 72.25,  1.25*Math.PI);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(150,310, 70, 149.22, 2*Math.PI);
    ctx.strokeStyle = "green";
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(160,310, 90, 347.93, 1.46*Math.PI);
    ctx.strokeStyle = "green";
    ctx.stroke();
}


function borda(){
    ctx.beginPath() ;
    ctx.fillStyle = "green";
    ctx.arc(80, 220, 16.5, 0, 2*Math.PI);
    ctx.fill();

    ctx.beginPath() ;
    ctx.fillStyle = "green";
    ctx.arc(230, 220, 16.5, 0, 2*Math.PI);
    ctx.fill();

    ctx.beginPath() ;
    ctx.fillStyle = "blue";
    ctx.arc(150, 120, 16.5, 0, 2*Math.PI);
    ctx.fill();

    ctx.beginPath() ;
    ctx.fillStyle = "blue";
    ctx.arc(150, 120, 16.5, 0, 2*Math.PI);
    ctx.fill();

    ctx.beginPath();
    ctx.arc(150,300, 41.5, 0, 2*Math.PI);
    ctx.fillStyle = "green";
    ctx.fill();

}

function escrever(){
        ctx.font = "20px Arial";
        ctx.fillStyle = "black";
        ctx.fillText("Canvas", 116, 50);


}


desenharRetangulos()
desenharLinhas()
borda()
desenharArcos()
escrever()