let resultado = document.querySelector("#resultado")
let aleatorio = Math.round(Math.random() * (0 + 100) - 0)
let inputs = document.querySelector("#inserir")
let button = document.getElementById("#botao")
botao.addEventListener("click",(e)=>{
    e.preventDefault()
    let numero = inputs.value
    adivinha(numero)
})
// FUNÇÃO ADIVINHA, TESTA PARA VER SE O NUMERO DIGITADO É IGUAL AO ALEATORIO
function adivinha(numero){
    if (numero > aleatorio){
        resultado.innerHTML = "Número Grande";
        resultado.style.setProperty("background-color", "blue");
    }
    else if  (numero < aleatorio){
        resultado.innerHTML = "Número Pequeno";
        resultado.style.setProperty("background-color", "red");
    }
    else if (numero == aleatorio){
        resultado.innerHTML = "Show!!!";
        resultado.style.setProperty("background-color", "green");
    }
}