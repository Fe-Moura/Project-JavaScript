let i = parseInt(prompt("Insira 1, 2 ou 3"))
let a = parseFloat(prompt("Insira um numero: "))
let b = parseFloat(prompt("Insira um numero: "))
let c = parseFloat(prompt("Insira um numero: "))
if (i === 1){
    if (a<b && a<c && b<c){
        window.alert("Ordem "+ a + b + c)
    }
    else if(a<b && a<c && b>c){
        window.alert("Ordem: "+ a + c +b)
    }
    else if(a>b && a<c && b<c){
        window.alert("Ordem: "+b +a +c)
    }
    else if(a>b && a>c && b<c){
        window.alert("Ordem: "+b +c +a)
    }
    else if(a<b && a>c && b>c){
        window.alert("Ordem: "+c +a +b)
    }
    else if(a>b && a>c && b>c){
        window.alert("Ordem: "+c +b +a)
    }
}
else if (i === 2){
    if(a<b && a<c && b<c){
        window.alert("Ordem "+c +b +a)
    }
    else if(a<b && a<c && b>c){
        window.alert("Ordem: "+b +c +a)
    }
    else if(a>b && a<c && b<c){
        window.alert("Ordem: "+c +a +b)
    }
    else if(a>b && a>c && b<c){
        window.alert("Ordem: "+a +c +b)
    }
    else if(a<b && a>c && b>c){
        window.alert("Ordem: "+b +a +c)
    }
    else if(a>b && a>c && b>c){
        window.alert("Ordem: "+a +b +c)
    }
}
else{
    if (a<b && a<c && b<c){
        window.alert("Ordem "+a +c +b)
    }
    else if(a<b && a<c && b>c){
        window.alert("Ordem " +a +b +c)
    }
    else if(a>b && a<c && b<c){
        window.alert("Ordem "+b +c +a)
    }
    else if(a>b && a>c && b<c){
        window.alert("Ordem "+b +a +c)
    }
    else if(a<b && a>c && b>c){
        window.alert("Ordem "+c +b +a)
    }
    else if(a>b && a>c && b>c){
        window.alert("Ordem "+c +a +b)
    }
}