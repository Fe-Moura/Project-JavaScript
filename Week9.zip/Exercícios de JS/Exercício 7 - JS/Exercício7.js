let base=0
let altura=0
while (base<=0 || altura<=0){
    base=parseInt(prompt("Entre com o valor da base do triângulo: "))
    altura=parseInt(prompt("Entre com o valor da altura do triângulo: "))
    if (base>0 && altura >0){
        area=(base*altura)/2
        console.log("Area do triangualo é: ", area)
        break
    }
}