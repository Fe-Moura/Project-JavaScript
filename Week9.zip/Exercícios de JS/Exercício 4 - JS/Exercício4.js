let altura=parseInt(prompt("Entre com a altura: "))
let peso=parseInt(prompt("Entre com o peso: "))

if (altura<1.20){
    if (peso<60){
        console.log("A")
    }
    else if (peso>=60 && peso<=90){
        console.log("D")
    }
    else if (peso>90){
        console.log("G")
    }
}
else if (altura>=1.20 && altura<=1.70){
    if (peso<60){
        console.log("B")
    }
    else if (peso>=60 && peso<=90){
        console.log("E")
    }
    else if (peso>90){
        console.log("H")
    }
}
else if (altura>1.70){
    if (peso<60){
        console.log("C")
    }
    else if (peso>=60 && peso<=90){
        console.log("F")
    }
    else if (peso>90){
        console.log("I")
    }
}
