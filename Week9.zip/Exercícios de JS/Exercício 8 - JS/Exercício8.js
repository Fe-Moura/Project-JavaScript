let escape = true;

let soma = 0;
let somaPar = 0;
let qt = 0;
let qtImpar = 0;
let media;
let mediaPar;
let maior;
let menor;
let impPercent;
let firstpass0 = true;
let firstpass1 = true;

while(escape){
    let n = prompt("Digite o número (digite SAIR para terminar):");
    if(n === "SAIR" || n === "sair") {
        escape = false;
    }else if(isNaN(parseFloat(n))){

    }else{
        n = parseFloat(n);
        soma += n;
        qt++;
        /*lógica do maior*/
        if (firstpass0) {
            maior = n;
            firstpass0 = false;
        } else {
            if (n > maior) {
                maior = n;
            }
        }

        /*lógica do menor*/
        if (firstpass1) {
            menor = n;
            firstpass1 = false;
        } else {
            if (n < menor) {
                menor = n;
            }
        }
        /*lógica par e ímpar*/
        if (n % 2 === 0) {
            somaPar += n;
        } else {
            qtImpar++;
        }
    }
}

media = soma/qt;
mediaPar = somaPar/(qt-qtImpar);
impPercent = (qtImpar/qt)*100;

console.log("Soma: "+soma);
console.log("Quantidade de números digitados: "+qt);
console.log("Média geral: "+media);
console.log("Maior número digitado: "+maior);
console.log("Menor número digitado: "+menor);
console.log("Média dos pares: "+mediaPar);
console.log(impPercent+"% dos números foram ímpares.");

alert("Abra o console");
