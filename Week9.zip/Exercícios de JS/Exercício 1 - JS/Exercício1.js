let l = prompt("Nota de Laboratório")
let s = prompt("Nota da Avaliação Semestral")
let f = prompt("Nota do Exame Final")

let n = ((l*2)+ (s*3) + (f*5))/10
window.alert("Nota final: " +n)

