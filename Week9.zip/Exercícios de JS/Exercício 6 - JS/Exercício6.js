let i=1
while (i<7){
    aluno=toString(prompt("Nome do aluno: "))
    nota1=parseFloat(prompt("Nota 1: "))
    nota2=parseFloat(prompt("Nota 2: "))
    media=(nota1+nota2)/2
    if (media<3){
        console.log(aluno,  "Reprovado")
    }
    else if (media>=3 && media<=7){
        console.log(aluno, "Exame")
    }
    else if (media>7){
        console.log(aluno, "Aprovado")
    }
    i=i+1

}