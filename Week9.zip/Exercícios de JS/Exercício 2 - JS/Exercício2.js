let n1 = prompt("Digite a primeira nota: ");
let n2 = prompt("Digite a segunda nota: ")
let n3 = prompt("Digite a terceira nota: ")

let media = (n1*2 + n2*3 + n3*5) / 10

if (media > 8.0){
    alert("Sua nota é A")
}
else if (media > 7.0){
    alert("Sua nota é B")
}
else if (media > 6.0){
    alert("Sua nota é C")
}
else if (media > 5.0){
    alert("Sua nota é D")
}
else{
    alert("Sua nota é E")
}
alert("Sua média é " + media)