let numero_de_termos = parseInt(prompt('Digite o número de termos: '))
var termo1 = 2
var termo2 = 7
var termo3 = 3

for (let i=1; i <= numero_de_termos; i++) {

    if (i == 1) {
        console.log(2)
    } else if (i == 2) {
        console.log(7)
    } else if (i == 3) {
        console.log(3)
    }

}
if (numero_de_termos > 3) {
    for (let i=1; i <= numero_de_termos; i++) {

        termo1 = termo1 * 2
        i++
        console.log(termo1,end=' ')

        if ( i <= numero_de_termos ) {
            termo2 = termo2 * 3
            console.log(termo2, end=' ')
            i++
        }

        if (i <= numero_de_termos) {

            termo3 = termo3 * 4
            console.log(termo3, end=' ')
            i++
        }
    }
}